package senhas;

public interface Senha {
    void senha();
}
